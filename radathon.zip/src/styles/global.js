export const colors = {
  primary: '#383838',
  secondary: 'white',
  tertiary: 'orange',
  bodytext: 'black'
};

export const fonts = {
  primary: 'Montserrat',
  secondary: 'athelas'
};



